package com.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book {
	@Id
	private int BookId;
	private String BookName;
	private String author;
	private String description;
	private int price;
	public int getBookId() {
		return BookId;
	}
	public void setBookId(int bookId) {
		BookId = bookId;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [BookId=" + BookId + ", BookName=" + BookName + ", author=" + author + ", description="
				+ description + ", price=" + price + "]";
	}
	public Book(int bookId, String bookName, String author, String description, int price) {
		super();
		BookId = bookId;
		BookName = bookName;
		this.author = author;
		this.description = description;
		this.price = price;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
}
