package com.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.entity.Book;
import com.service.BookService;

@Controller
public class BookController {
	
	@Autowired
	BookService bookService;
	
	//handler methods
	//inject service
	
	@RequestMapping(path="/")
	public String getIndexPage() {
		return "index";
	}
	@RequestMapping(path="/addNewBook")
	public String addNewBook() {
		return "addNewBook";
	}
	
	@RequestMapping(path="/bookAddedSuccessful", method = RequestMethod.POST)
	public String bookAddedSuccess(@ModelAttribute Book book,Model m) {
		
		this.bookService.saveNewBook(book);
		//------------------------
		List<Book> books = this.bookService.getAllData();	
		m.addAttribute("books", books);
		
		return "display";
	}
	@RequestMapping(path="/delete/{bookId}")
	public String deleteDataById(@PathVariable("bookId")int bookId,Model m) {
		//first get and delete
		Book book = this.bookService.getSingleData(bookId);
		
		
		this.bookService.deleteData(book);
		
		//after deleting the data 
		List<Book> books=this.bookService.getAllData();
		m.addAttribute("books", books);
		
		return "display";
		
	}
	
	//update
	@RequestMapping(path="/update/{bookId}")
	public String updateForm(@PathVariable("bookId")int bookId,Model m) {
		Book book = this.bookService.getSingleData(bookId);
		m.addAttribute("book", book);
		return "updateForm";
		
	}
	@RequestMapping(path="update/updateSuccess", method= RequestMethod.POST)
	public String updateSuccess(@ModelAttribute Book book, Model m) {
		//update
		this.bookService.updateData(book);
		
		//get all data
		List<Book> books = this.bookService.getAllData();
		m.addAttribute("books", books);
		return "display";
	}
	
	
	
}
