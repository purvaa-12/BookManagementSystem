package com.repositary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.Book;

@Repository
public class BookRepositary {
//inject hibernateTemplate
	
	@Autowired
	HibernateTemplate hibernateTemplate;

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	//save
	//-----------------
	@Transactional
	public void saveNewBook(Book book) {
		this.hibernateTemplate.save(book);
		
	}
	
	//get all data
	public List<Book> getAllBooks() {
		List<Book> books =this.hibernateTemplate.loadAll(Book.class);
	return books;
	}
	
	public Book getSingleData(int id) {
		Book book = this.hibernateTemplate.get(Book.class, id);
		return book;
	}
	@Transactional
	public void deleteData(Book book) {
		this.hibernateTemplate.delete(book);
	}
	@Transactional
	public void updateData(Book book) {
		this.hibernateTemplate.update(book);
	}
}
