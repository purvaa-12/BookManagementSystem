package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Book;
import com.repositary.BookRepositary;

@Service
public class BookService {
       //inject repositary
	
	@Autowired
	BookRepositary bookRepositary;
	
	public void saveNewBook(Book book) {
		this.bookRepositary.saveNewBook(book);
	}
	
	public List<Book> getAllData() {
		List<Book> books = this.bookRepositary.getAllBooks();
		return books;
	}
	
	public Book getSingleData(int id) {
		Book book = this.bookRepositary.getSingleData(id);
		return book;
	}
	
	public void deleteData(Book book) {
		this.bookRepositary.deleteData(book);
	}
	
	public void updateData(Book book) {
		this.bookRepositary.updateData(book);
	}
}
